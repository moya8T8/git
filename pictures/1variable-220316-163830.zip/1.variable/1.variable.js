let a = 0;
console.log(a);

a = 1;
console.log(a);

let b;
console.log(b);

b = 2;
console.log(b);
