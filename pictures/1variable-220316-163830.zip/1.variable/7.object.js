let name = 'apple';
let color = 'red';
let display = '🍎';
let orangeName = 'orange';

let apple = {
  name: 'apple',
  color: 'red',
  display: '🍎',
};
console.log(apple);
console.log(apple.name);
console.log(apple.color);
console.log(apple.display);

let orange = {
  name: '오렌지',
  color: 'orange',
  display: '🍊',
};
console.log(orange);
